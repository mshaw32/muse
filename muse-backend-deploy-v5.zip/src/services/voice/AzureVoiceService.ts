/**
 * AzureVoiceService — Phase 4 backend-facing Azure AI Foundry Voice
 * service.
 *
 * Thin wrapper around the shared `VoiceService` from MuseRuntime (the
 * runtime's single voice composition root). Provides the async surface the
 * `/api/voice/*` routes need: session start/stop, speech synthesis, status,
 * and device queries. Falls back to the `MockVoiceProvider` automatically
 * whenever configuration is mocked (i.e. no real Azure AI Foundry Voice
 * credentials are configured), so this service behaves identically today
 * and once real Azure connectivity lands.
 */

// Type definitions for VoiceService stub
interface VoiceStatusSnapshot {
  status: string;
  [key: string]: any;
}

interface VoiceTranscript {
  text: string;
  confidence: number;
  isFinal: boolean;
}

type VoiceService = any;

// Stub voice diagnostics for Phase 4 features
const voiceDiagnostics = {
  getConfiguration: () => ({
    provider: "mock",
    connectionState: "not_connected",
    authenticationMode: "none",
    model: "mock",
    voiceProfile: "default",
  }),
  runAll: async () => ({
    status: "ok",
    tests: [],
  }),
};

export interface StartSessionResult {
  session: ReturnType<VoiceService["session"]["getActiveSession"]>;
}

export interface FoundryStatus {
  provider: "mock" | "foundry";
  connectionState: string;
  authenticationMode: string;
  model: string;
  voiceProfile: string;
}

export class AzureVoiceService {
  private readonly voice: VoiceService;
  private lastTranscript: VoiceTranscript | null = null;
  private partialTranscript: VoiceTranscript | null = null;

  constructor(voice: VoiceService) {
    this.voice = voice;
  }

  isMock(): boolean {
    return this.voice.config.isMockProvider();
  }

  /** Feeds real microphone PCM audio (captured client-side) into the active Foundry STT session. */
  feedAudio(pcmChunk: Buffer): void {
    this.voice.feedAudio(pcmChunk);
  }

  start(): StartSessionResult {
    const session = this.voice.startSession({
      onPartialTranscript: (transcript: any) => {
        this.partialTranscript = transcript as VoiceTranscript;
      },
      onFinalTranscript: (transcript: any) => {
        this.lastTranscript = transcript as VoiceTranscript;
        this.partialTranscript = null;
      },
    });
    return { session };
  }

  async stop() {
    const result = await this.voice.stopSession();
    this.lastTranscript = result.transcript;
    return result;
  }

  async speak(text: string, voiceProfileId?: string, rate?: number, pitch?: number) {
    return this.voice.speakPhase4({ text, voiceProfileId, rate, pitch });
  }

  getStatus(): VoiceStatusSnapshot {
    return this.voice.getStatus();
  }

  /** Phase 4.1 — extended provider/connection/authentication status. */
  getFoundryStatus(): FoundryStatus {
    const config = voiceDiagnostics.getConfiguration();
    return {
      provider: (config.provider as "mock" | "foundry") || "mock",
      connectionState: config.connectionState,
      authenticationMode: config.authenticationMode,
      model: config.model,
      voiceProfile: config.voiceProfile,
    };
  }

  async runDiagnostics() {
    return voiceDiagnostics.runAll();
  }

  getLastTranscript(): VoiceTranscript | null {
    return this.lastTranscript;
  }

  getPartialTranscript(): VoiceTranscript | null {
    return this.partialTranscript;
  }

  listMicrophones() {
    return this.voice.devices.listMicrophones();
  }

  listSpeakers() {
    return this.voice.devices.listSpeakers();
  }

  selectMicrophone(deviceId: string) {
    return this.voice.devices.selectMicrophone(deviceId);
  }

  selectSpeaker(deviceId: string) {
    return this.voice.devices.selectSpeaker(deviceId);
  }
}
